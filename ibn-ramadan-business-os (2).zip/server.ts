import express from "express";
import path from "path";
import dotenv from "dotenv";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json());

// Initialize Gemini Client Lazily/Safely so it won't crash on start if API key is missing
let aiClient: GoogleGenAI | null = null;
const apiKey = process.env.GEMINI_API_KEY;

if (apiKey) {
  try {
    aiClient = new GoogleGenAI({
      apiKey: apiKey,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build",
        },
      },
    });
    console.log("Successfully initialized GoogleGenAI client on the backend.");
  } catch (error) {
    console.error("Failed to initialize GoogleGenAI client:", error);
  }
} else {
  console.warn("⚠️ GEMINI_API_KEY environment variable is not defined, running in dynamic fallback mode.");
}

// 1. Helper function for a highly sophisticated, dynamic Arabic fallback response 
// in case Gemini API is not available/configured, so it answers the user's exact context!
function generateDynamicFallback(question: string, persona: string): string {
  const norm = question.toLowerCase();
  
  // Extract budget or numbers
  const budgetMatch = question.match(/(\d+[\d,.]*)/);
  const budget = budgetMatch ? `${budgetMatch[1]} جنيه` : "ميزانية محدودة";
  
  // Detect domain
  let domainAr = "مشروعك التجاري";
  let domainDetails = "";
  
  if (norm.includes("زراع") || norm.includes("نبات") || norm.includes("أرض") || norm.includes("أسمد")) {
    domainAr = "القطاع الزراعي";
    domainDetails = "من خلال استغلال الأرض والتشبيك مع الموردين المحليين للبذور العضوية، وإدخال تقنيات الري الذكية الموفرة للمياه.";
  } else if (norm.includes("ملابس") || norm.includes("أزياء") || norm.includes("موضة")) {
    domainAr = "قطاع الملابس والمنسوجات";
    domainDetails = "عبر الاستعانة بورش الخياطة المحلية الصغيرة لتوفير تشكيلات ممتازة بأقل تكلفة، والترويج من خلال مصوري السوشيال ميديا الشباب.";
  } else if (norm.includes("عقارات") || norm.includes("شقة") || norm.includes("فيلا")) {
    domainAr = "التسويق والاستثمار العقاري";
    domainDetails = "من خلال استهداف المغتربين والمهتمين بالاستثمار الآمن للمستقبل بعيداً عن تقلبات الأسعار.";
  } else if (norm.includes("أكل") || norm.includes("مطعم") || norm.includes("غذاء") || norm.includes("مطبخ")) {
    domainAr = "صناعة الأغذية والمطاعم";
    domainDetails = "من خلال التركيز على وجبات تيك أواي متخصصة تضمن الدوران الفوري السريع للأموال.";
  } else if (norm.includes("برمج") || norm.includes("تطبيق") || norm.includes("كود") || norm.includes("موقع")) {
    domainAr = "قطاع البرمجيات والحلول السحابية";
    domainDetails = "بالاعتماد على بنية برمجية سحابة معيارية لا تكلف شيئاً في فترة الفراغ لخفض نسبة استهلاك الخوادم.";
  }
  
  if (persona === "ramadan") {
    return `🔮 [ابن رمضان AI Live - سعد رمضان]
    
أهلاً بك يا بطل! يسعدني جداً إجابتك على هذا السؤال الدقيق بخصوص الاستثمار بميزانية ${budget} في ${domainAr}..

إليك خطتي الفنية المباشرة من قلب السوق المصري لتنفيذ فكرتك بذكاء:

1. إدارة رأس المال المتوفر (${budget}):
يا هندسة، الميزانية دي كبداية ممتازة جداً لو وزعتها صح. لازم تخصص 40% للتسويق المباشر وبناء التفاعل، 45% للمستلزمات الإنتاجية المباشرة، و15% كاش طوارئ. إياك تحط الفلوس كلها في أصول ثابتة من أول يوم.

2. استراتيجية التشغيل والتنفيذ:
${domainDetails || "ابدأ بتقديم النسخة الأولية الأدنى MVP من خدمتك لمعارفك والعملاء المحيطين بك مباشرة واحصل على تقييمهم العفوي قبل التوسع لضمان ثقة ممتازة."}

3. الأتمتة وفرض الكفاءة:
استخدم أدوات الذكاء الاصطناعي لكتابة المحتوى وجدولة الردود، عشان توفر جهدك ووقتك في تعزيز جودة الخدمة الحقيقية والتواصل الفردي مع المهتمين.

✨ شعارنا اليوم: "يا بطل، الشطارة مش في كبر ميزانيتك، الشطارة في كيفية تدوير الـ ${budget} لتوليد أول عميل سعيد!"`;
  }
  
  if (persona === "strategist") {
    return `💼 [ابن رمضان AI Live - شريك الأعمال الإستراتيجي]
    
تقرير الجدوى السريع لـ: "${question}"
إليك هيكلة استرشادية لاستثمار ميزانية قدرها ${budget} في قطاع ${domainAr}:

• التوزيع الموصى به للميزانية (${budget}):
- 50% أصول تشغيلية ذات دوران سريع (CapOp).
- 30% تسويق تفاعلي مباشر (CAC Optimization).
- 20% احتياطي سيولة نقدية مباشر لحالات الطوارئ الميدانية.

• آلية التنفيذ والترويج:
${domainDetails || "عبر التركيز على سوق نيش محدد جداً لتفادي منافسة الكيانات الضخمة والسيطرة على التكلفة الإعلانية بشكل تام."}

• التوقعات المالية الفورية:
- معدل استرداد تكلفة العميل المتوقع: 30-45 يوماً من بدء التشغيل الفعلي.
- نقطة التعادل المستهدفة: بعد إتمام أول 12-15 عملية بيع حقيقية بالكامل.`;
  }
  
  if (persona === "coach") {
    return `🔥 [ابن رمضان AI Live - المدرب التحفيزي للأداء]
    
يا بطل البث، كلامك رائع وسؤالك بيدل على طاقة وشجاعة حقيقية! ميزانية وقدرها ${budget} مع رغبة في استكشاف ${domainAr} هي البداية الحقيقية لقصة نجاحك اللي الناس هتحكي عنها بكرة!

اسمعني كويس وحط الكلام ده قدام عينك في البث:
1. لا تنتظر اللحظة المثالية: الـ ${budget} دي كافية جداً عشان تاخد الخطوة الأولى وتتحرك حالا. الخوف هو اللي بيوقفك مش قلة الفلوس!
2. ${domainDetails || "انزل الملعب وجرب بنفسك واعرض شغلك بشغف وحب، الناس بتشتري طاقتك وثقتك قبل ما تشتري منتجك!"}
3. ابدأ البث اليوم وافتخر بميزانيتك وخطواتك الأولى، الجمهور بيعشق الرواد العفويين العصاميين وسيدعمونك حتى القمة!

💪 المستحيل مجرد كلمة في قاموس اللي لسه ما جربش. انطلق والكل معاك اليوم!`;
  }
  
  // default/coder
  return `💻 [ابن رمضان AI Live - المطور البرمجي العبقري]
  
تحليل معماري منطقي لاستفسارك حول استثمار ${budget} في ${domainAr}:

1. تبسيط البنية النموذجية:
نحن بحاجة إلى تصميم بنية خفيفة تركز على المخرجات الأساسية (Lean Methodology). لتجنب المصاريف الهندسية، استخدم واجهة بسيطة تجمع فيها طلبات العملاء وتحتفظ ببياناتهم في مصفوفة تخزين محلية أو قاعدة موحدة.

2. تنفيذ آلية الاستجابة في ${domainAr}:
${domainDetails || "بناء تجربة مستخدم سريعة تركز على التفاعل والوضوح التام لخلق ثقة فورية مع الزبون."}

3. قاعدة تعظيم العائد التقنية:
- التكلفة التشغيلية للخادم: 0$ (استخدم استضافات مجانية ونماذج سحابية خادمة منخفضة التكلفة).
- التركيز على الدورة التشغيلية لحصد السيولة وإعادة استثمارها برمجياً لرفع كفاءة القياس.`;
}

// 2. Main Generation Endpoint combining real Gemini and premium Fallback API
app.post("/api/generate", async (req, res) => {
  const { question, persona } = req.body;
  if (!question || typeof question !== "string") {
    return res.status(400).json({ error: "الرجاء توفير نص السؤال بشكل صحيح." });
  }

  const activePersona = persona || "ramadan";
  
  // Setup system instructions matching the selected expert persona
  let systemInstruction = "";
  if (activePersona === "ramadan") {
    systemInstruction = `أنت سعد رمضان، خبير الأتمتة المصري الملقب بالأب الروحي للمنظومة. 
تحدث باللهجة المصرية الدافئة والمحفزة لرواد الأعمال وصناع المحتوى. 
كن تفصيلياً وعملياً ومحفزاً جداً، واستخدم تعبيرات مصرية أصيلة لتشجيعهم مثل (يا هندسة، يا بطل، يا وحش، الشغل دغري، السوق عاوز صاحي، حط ايدك في المية الباردة). 
أجب دوماً وبدقة متناهية على تفاصيل سؤال السائل وخلفيته والقطاع والميزانية الموضحة بسؤاله ولا تبخل عليه بالنصيحة والخبرة الفنية الميدانية.`;
  } else if (activePersona === "strategist") {
    systemInstruction = `أنت شريك الأعمال الإستراتيجي، مخطط سحابي واستثماري حاد الذكاء يركز على العائد على الاستثمار وصناعة الهويات التجارية.
تحدث بلغة فصيحة مرنة وسلسة وجذابة لرواد الأعمال.
كن موجزاً، عملياً ومقنعاً، واجعل إجابتك مقسمة في شكل نقاط محددة تركز على التميز والتثمين المالي والخطوات العملية المحسوبة بدقة لميزانيتهم وحالتهم.`;
  } else if (activePersona === "coach") {
    systemInstruction = `أنت المدرب التحفيزي للأداء وشعلة الطاقة الإيجابية للجمهور في البث المباشر.
شغفك هو كسر الخوف وتحفيز صناع المحتوى ورواد الأعمال على الاستمرار اليومي وتجاوز العقبات المادية واللوجستية.
استخدم لغة خطابية قوية وحماسية مفعمة بالثقة الكبرى والنصائح الجريئة وتخاطب رائع لصناعة التفاعل اللعب في تيك توك ومقاومة الإحباط.`;
  } else {
    systemInstruction = `أنت المطور البرمجي العبقري، خبير التقنية وهياكل المنظومات وبنى التكنولوجيا المعيارية.
تحدث بأسلوب السهل الممتنع، وركب مصطلحات تقنية معبرة وممتعة بطريقة مبسطة يفهمها أي مستمع.
ركز على خفض التكاليف البرمجية، وتحقيق أقصى فاعلية في الأداء بأدوات ذكية وأتمتة فعالة ملائمة لسؤال المستخدم وميزانيته.`;
  }

  // If Gemini client is ready, let's use it!
  if (aiClient) {
    try {
      console.log(`Sending query to Gemini for persona: ${activePersona}`);
      const response = await aiClient.models.generateContent({
        model: "gemini-3.5-flash",
        contents: question,
        config: {
          systemInstruction: systemInstruction,
          temperature: 0.85,
        },
      });

      const generatedText = response.text;
      
      if (generatedText) {
        return res.json({ 
          success: true, 
          text: generatedText, 
          source: "gemini" 
        });
      }
    } catch (apiError: any) {
      console.error("Gemini API generation error:", apiError);
      // Fallback inside catch as a safety net
    }
  }

  // Safe and precise dynamic fallback
  console.log("Serving dynamic rule-based fallback response.");
  const mockText = generateDynamicFallback(question, activePersona);
  return res.json({ 
    success: true, 
    text: mockText, 
    source: "fallback" 
  });
});

// 3. Vite development middleware / Static production handler setup
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`🚀 Ibn Ramadan AI Live Server ready on http://0.0.0.0:${PORT}`);
  });
}

startServer();

import { createClient } from "@supabase/supabase-js";

// Retrieve environment variables via Vite's import.meta.env safely
const metaAny = (typeof import.meta !== "undefined" ? import.meta : null) as any;
const supabaseUrl = (metaAny && metaAny.env && metaAny.env.VITE_SUPABASE_URL) || "";
const supabaseAnonKey = (metaAny && metaAny.env && metaAny.env.VITE_SUPABASE_ANON_KEY) || "";

export const isSupabaseConfigured = !!(supabaseUrl && supabaseAnonKey);

// Guard client initialization to avoid throwing errors on empty credentials
export const supabase = createClient(
  supabaseUrl || "https://placeholder-url.supabase.co",
  supabaseAnonKey || "placeholder-key"
);

/**
 * SQL Schema for creation inside Supabase dashboard:
 * 
 * create table public.clients (
 *   id text not null primary key,
 *   company_name text not null,
 *   brand_name text not null,
 *   username text not null unique,
 *   password text not null,
 *   subscription text not null,
 *   status text not null,
 *   expiry_date text not null,
 *   features jsonb not null default '{}'::jsonb,
 *   created_at text not null
 * );
 * 
 * -- Enable Row Level Security (RLS) can be bypassed/configured as needed or:
 * -- alter table public.clients enable row level security;
 * -- create policy "Enable read/write for all" on public.clients for all using (true) with check (true);
 */

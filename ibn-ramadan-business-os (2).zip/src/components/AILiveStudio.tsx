import React, { useState, useEffect, useRef } from "react";
import { 
  Sparkles, Monitor, Maximize2, Minimize2, Copy, Check, Play, Square, 
  ChevronLeft, History, Sliders, Type, Palette, Video, Volume2, VolumeX,
  RefreshCw, Trash2, HelpCircle, Send, Star, Zap, Share2
} from "lucide-react";

interface QuestionItem {
  id: string;
  question: string;
  answer: string;
  persona: string;
  timestamp: string;
}

const TEMPLATE_PROMPTS = [
  {
    title: "💡 ريادة الأعمال",
    question: "اعطني 3 نصائح ذهبية لتأسيس مشروع تجاري ناجح في السوق المصري بميزانية محدودة.",
    category: "business"
  },
  {
    title: "🚀 دقيقة تحفيزية",
    question: "بث خطبة حماسية قصيرة كقائد أعمال يحمس المتابعين على البث المباشر للاستمرار وتحدي عقبات السوق.",
    category: "motivation"
  },
  {
    title: "💻 تطوير برمجيات",
    question: "اشرح لي بأبسط لغة ممكنة مفهوم الذكاء الاصطناعي التوليدي ومستقبل تطبيقات الوب في 2026.",
    category: "tech"
  },
  {
    title: "📈 خطة تسويقية",
    question: "فكرة حملة إعلانية مبتكرة وصادمة لبراند ملابس محلي باستخدام السوشيال ميديا.",
    category: "marketing"
  },
  {
    title: "🧠 سؤال وجواب",
    question: "كيف أدير وقتي اليومي بذكاء كصانع محتوى يبث يومياً ويعمل بشكل منفرد؟",
    category: "productivity"
  }
];

const EXPERT_PERSONAS = [
  {
    id: "ramadan",
    name: "سعد رمضان",
    role: "خبير الأتمتة والتحليلات العميقة الأب الروحي للمنظومة",
    style: "تفصيلي وعملي مع عبارات تشجيعية مصرية أصيلة",
    voiceRate: 0.95
  },
  {
    id: "strategist",
    name: "شريك الأعمال الإستراتيجي",
    role: "مخطط سحابي واستثماري حاد الذكاء",
    style: "مختصر، نقاط محددة، لغة أرقام ونسب مئوية جذابة",
    voiceRate: 1.05
  },
  {
    id: "coach",
    name: "المدرب التحفيزي للأداء",
    role: "صانع الطاقات الإيجابية للجمهور",
    style: "نغمة خطابية حماسية، يركز على إشعال شغف البث المباشر وتفاعل التيك توك",
    voiceRate: 1.15
  },
  {
    id: "coder",
    name: "المطور البرمجي العبقري",
    role: "مخطط البنى التحتية والمنظومات",
    style: "لغة تقنية ممتعة تتداخل معها كلمات برمجية بأسلوب السهل الممتنع",
    voiceRate: 1.0
  }
];

// Fallback high-quality answers array for simulated local generation
const LOCAL_RESPONSES: Record<string, string[]> = {
  ramadan: [
    `🔮 إجابة سعد رمضان الفورية الكبرى:
    
1. البدء بذكاء سحابي: لا تبنِ أصولاً مكلفة في البداية. استأجر الخدمة السحابية بدلاً من السيرفر، واستخدم الأدوات المفتوحة بدلاً من التخصيص المكلف.
2. التركيز على هامش الربح السريع: المشروع الناجح هو اللي يدور دورة رأس ماله في 30 يوم. فكّرك في حلول تسويقية فورية ولا تنتظر المدى البعيد.
3. التمويل الذاتي: العميل هو المستثمر الأول لك. بع الخدمة قبل أن تكتمل برمجتها بالكامل لتضمن أن هناك حوجة حقيقية.

✨ نصيحة ابن رمضان AI: "يا بطل، الطريق خطوة بخطوة، والمنصة اتعملت عشان تشيل عنك كابل الأفكار المعقّدة وتديك الخلاصة الفنية!"`,

    `🔥 الخطبة الحماسية من قلب الاستوديو الفني:
    
"يا شباب البث، يا صناع المستقبل.. السوق مش عاوز المترددين!
الأزمات بتخلق قادة، والنهارده التكنولوجيا خلتك قادر تقعد في بيتك وتصنع إمبراطورية تجارية تعبر الحدود.
كل غلطة هي سطر في كود نجاحك، وكل تعليق سلبي هو اختبار لثبات عزميتك.
استمر في بثك، طور من منتجك، واعتمد على فكر الأتمتة عشان تكبر وتوسع. أحلامكم مش بعيدة، بس محتاجة شخص يصحى كل يوم ويقول: أنا جاهز للتحدي!"`,

    `💻 الذكاء الاصطناعي التوليدي ببساطة:
    
- إنه الآلة التي لم تعد محفّظة بل أصبحت تفكر وتصنع وتكتب مثلك تماماً!
- في عام 2026، تطبيقات الوب لم تعد تكتفي بعرض البيانات؛ بل أصبحت تفهم سياق المستخدم وتولد له الحل الفوري.
- النصيحة الذهبية للمبرمجين: لا تحفظ الأكواد، بل افهم كيف تبني بنية منطقية توظف بها نماذج الذكاء الاصطناعي لصالح عملائك.`,

    `⚡ لوحة تسويقية خارقة لبراند ملابس محلي:
    
1. حملة 'البرواز الفارغ': ابعث علب هدايا فاخرة وفارغة لـ 20 صانع محتوى، وفي الداخل باركود مكتوب عليه: 'تصميمك لسه ما اتخلقش، ادخل حدده وهنطبعلك قطعة فريدة لوحدك'.
2. استخدام إعلانات الـ Hook السريعة: بداية بثانية واحدة تظهر تمزق نسيج تليها فوراً خيارات ألوان متوهجة تجذب النظر.
3. الخيار المستدام: اعلن أن كل تيشيرت يتم شراؤه يساهم في دعم ورشة تصنيع محلية صغيرة بمصر لتحفيز الجانب الأخلاقي والوطني للمستهلك.`,

    `🧠 إدارة الوقت لصناع المحتوى والرواد:
    
- قاعدة الـ 120 دقيقة الذهبية: أول ساعتين من يومك للهياكل الأساسية والإنتاج الحقيقي، بعيداً تماماً عن تصفح السوشيال ميديا.
- الأتمتة التلقائية: جدولة منشوراتك وبثوثك الأسبوعية دفعة واحدة يوم الأحد لترتاح باقي الأسبوع وتتفرغ للتواصل المباشر مع المتابعين.
- جودة النوم والراحة البصرية: المنصة صممت باللون الأزرق المعتم لحماية عينيك أثناء البث الممتد!`
  ],
  strategist: [
    `💼 تحليل إستراتيجي فوري:
    
• التخطيط المالي: خصص 50% للتسويق المباشر القائم على التفاعل، 30% لتوفير الخدمة بجودة فائقة، و20% احتياطي تشغيلي للطوارئ.
• قاعدة العملاء المستهدفة: ابدأ بـ 10 عملاء مثاليين وقدم لهم رعاية فائقة فائقة الأولوية بدلاً من استهداف الآلاف بمستوى خدمة متوسط.
• مقياس التوسع السنوي: استثمر الأرباح المتولدة فوراً في تعزيز أتمتة الردود وإصدارات التراخيص الرقمية لتحسين هوامش الربح.`,

    `📈 الإستراتيجية كالسهم الحاد:
    
"التركيز هو أقوى سلاح اقتصادي تمتلكه حالياً.
إذا كنت تبيع للجميع، فأنت لا تبيع لأحد. حدد تخصصك بدقة متناهية، وسيرتفع قيمة البراند الخاص بك تلقائياً.
متابع واحد متفاعل ومستعد لشراء خدماتك أفضل من 100,000 مشاهد صامت. ابنِ مجتمعاً حول علامتك التجارية، وستشاهد كيف تتحول الأرقام إلى تيار مستمر من المبيعات."`,

    `📊 البنية التحتية السحابية لعام 2026:
    
• كفاءة تكلفة مطلقة: خوادم Serverless تتقلص للصفر وقت الخمول، مما يوفر 75% من قيمة الفاتورة الشهرية.
• أوقات تحميل فائقة السرعة: نقل البيانات عبر شبكات Edge القريبة من المستخدم لضمان سرعات استجابة تقل عن 50 ملي ثانية.
• تكامل الذكاء المدمج: تحسين واجهات الاستخدام بمولدات ذكية لتقليل فترات انتظار العملاء.`
  ],
  coach: [
    `🔥 طاقتك هي مغناطيس أرباحك اليوم!
    
1. الابتسامة والصوت العالي: أول 3 ثواني من ظهورك تحدد هل المشاهد هيكمل البث ولا هيعمل سكرول. اظهر بطاقة جبارة!
2. التفاعل التشاركي: اسأل المتابعين أسئلة واذكر أسماءهم بانتظام في البث. العميل بيحب يشعر إنه مرئي ومسموع!
3. الاستمرارية المنضبطة: البث المباشر مش موجة وهتعدي، ده التزام يومي بميعاد ثابت بيبني ثقة حديدية بينك وبين عملائك.`,

    `⚡ رسالة لإثارة تليكوم وتيك توك:
    
"اضرب بقوة، لا تتوقف!
الكل يقدر يبدأ، بس القليل جداً اللي بيقدر يكمل ويحتوي هجمات السوق ويحولها لفرص ذهبية.
أنت مش داخل تلعب، أنت داخل تصنع هوية وعلامة تجارية تفتخر بيها قدام الكل.
شغّل الاستوديو، جهّز الشاشة، وخلّي العالم كله يشوف إمكانياتك الحقيقية حالا!"`
  ],
  coder: [
    `💻 كودك نظيف.. حياتك منظمة:
    
1. تجنب التكرار (DRY - Don't Repeat Yourself): طبّق هذا المبدأ على أكواد مشروعك وعلى مهام يومك المكررة عبر برمجتها تلقائياً.
2. الهيكلية المعيارية: قسّم أي مشكلة ضخمة إلى أجزاء ووظائف مستقلة صغيرة جداً يسهل التحكم بها وحلها واحدة تلو الأخرى.
3. التست المستمر: ابدأ بالتحقق والتطوير خطوة بخطوة عشان لما ترفع تطبيقك سحابياً ما تتفاجئش بانهيار المنظومة!`
  ]
};

export default function AILiveStudio() {
  const [question, setQuestion] = useState("");
  const [isGenerating, setIsGenerating] = useState(false);
  const [answer, setAnswer] = useState("مرحباً بك في لوحة ابن رمضان AI Live الفاخرة المجهزة خصيصاً للمدربين وصناع المحتوى والرواد لبثوث التيك توك وOBS! اكتب سؤالك في اليمين واشعل الطاقة الحماسية للبث المباشر.");
  const [activePersona, setActivePersona] = useState("ramadan");
  const [fontSize, setFontSize] = useState<"sm" | "md" | "lg" | "xl" | "2xl" | "3xl">("xl");
  const [backgroundMode, setBackgroundMode] = useState<"slate" | "green" | "transparent" | "neon">("slate");
  const [history, setHistory] = useState<QuestionItem[]>([]);
  const [streamTicker, setStreamTicker] = useState("🔥 مرحباً بكم في البث المباشر! شاركوا البث واطرحوا أسئلتكم للحصول على إجابات فورية من منظومة ابن رمضان AI Live 🎓");
  const [isEditingTicker, setIsEditingTicker] = useState(false);
  const [isSpeechAvailable, setIsSpeechAvailable] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [copied, setCopied] = useState(false);
  
  // Presentation modes
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [showStreamOverlay, setShowStreamOverlay] = useState(true);

  // Auto scroll ref for output
  const outputEndRef = useRef<HTMLDivElement>(null);
  const presentationRef = useRef<HTMLDivElement>(null);

  // Check speech synthesis compatibility
  useEffect(() => {
    if (typeof window !== "undefined" && window.speechSynthesis) {
      setIsSpeechAvailable(true);
    }
    
    // Load local storage history to maintain persistency without Supabase
    const savedHistory = localStorage.getItem("ramadan_live_history");
    if (savedHistory) {
      try {
        setHistory(JSON.parse(savedHistory));
      } catch (e) {
        console.error(e);
      }
    }
  }, []);

  const saveHistoryToStorage = (updatedHistory: QuestionItem[]) => {
    localStorage.setItem("ramadan_live_history", JSON.stringify(updatedHistory));
  };

  const handleGenerate = async (e?: React.FormEvent, customPrompt?: string) => {
    if (e) e.preventDefault();
    const activeQuestion = customPrompt || question;
    if (!activeQuestion.trim()) return;

    setIsGenerating(true);
    setAnswer(""); // clear for typing effect

    // stop speaking if already running
    if (isSpeaking) {
      handleStopSpeaking();
    }

    // Try to trigger real @google/genai client if possible or simulate smart high-fidelity streaming
    try {
      let targetResponse = "";
      let source = "local";

      try {
        const response = await fetch("/api/generate", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            question: activeQuestion,
            persona: activePersona,
          }),
        });

        if (response.ok) {
          const data = await response.json();
          if (data && data.success) {
            targetResponse = data.text;
            source = data.source || "gemini";
          }
        }
      } catch (fetchErr) {
        console.error("Fetch request to /api/generate failed, using local matching:", fetchErr);
      }

      // If fetch failed or we got an empty response, use local keyword matcher
      if (!targetResponse) {
        const normalizedQuery = activeQuestion.toLowerCase();
        const currentPersonaList = LOCAL_RESPONSES[activePersona] || LOCAL_RESPONSES.ramadan;
        
        if (normalizedQuery.includes("نصائح") || normalizedQuery.includes("مشروع") || normalizedQuery.includes("تأسيس") || normalizedQuery.includes("فلوس") || normalizedQuery.includes("مال")) {
          targetResponse = currentPersonaList[0];
        } else if (normalizedQuery.includes("حماس") || normalizedQuery.includes("تحفيز") || normalizedQuery.includes("خطبة") || normalizedQuery.includes("بث") || normalizedQuery.includes("لايف")) {
          targetResponse = currentPersonaList[1];
        } else if (normalizedQuery.includes("برمج") || normalizedQuery.includes("ذكاء") || normalizedQuery.includes("تطبيقات") || normalizedQuery.includes("وب") || normalizedQuery.includes("كود")) {
          targetResponse = currentPersonaList[2];
        } else if (normalizedQuery.includes("تسويق") || normalizedQuery.includes("حملة") || normalizedQuery.includes("براند") || normalizedQuery.includes("بيع")) {
          targetResponse = currentPersonaList[3];
        } else if (normalizedQuery.includes("وقت") || normalizedQuery.includes("إدارة") || normalizedQuery.includes("تنظيم") || normalizedQuery.includes("يومي")) {
          targetResponse = currentPersonaList[4];
        } else {
          // Random fallback from persona presets
          const randIndex = Math.floor(Math.random() * currentPersonaList.length);
          targetResponse = currentPersonaList[randIndex];
        }
        source = "local";
      }

      // Format response nicely if it's raw from Gemini
      const formattedResponse = (source === "gemini")
        ? `💡 إجابة مخصصة لسؤالك: "${activeQuestion}"
👤 المستشار النشط: ${EXPERT_PERSONAS.find(p => p.id === activePersona)?.name}

${targetResponse}`
        : targetResponse;

      // Typewriter Effect simulation
      let currentLength = 0;
      const interval = setInterval(() => {
        if (currentLength < formattedResponse.length) {
          setAnswer(formattedResponse.substring(0, currentLength + 4));
          currentLength += 4;
          if (outputEndRef.current) {
            outputEndRef.current.scrollIntoView({ behavior: "smooth" });
          }
        } else {
          clearInterval(interval);
          setIsGenerating(false);

          // Add to history
          const neItem: QuestionItem = {
            id: `q_${Date.now()}`,
            question: activeQuestion,
            answer: formattedResponse,
            persona: activePersona,
            timestamp: new Date().toLocaleTimeString("ar-EG", { hour: "2-digit", minute: "2-digit" })
          };
          
          setHistory(prev => {
            const updated = [neItem, ...prev].slice(0, 30); // keep last 30
            saveHistoryToStorage(updated);
            return updated;
          });
        }
      }, 25);

    } catch (e) {
      console.error(e);
      setAnswer("حدث خطأ أثناء الاتصال بالخادم الذكي سحابياً للأسف. يرجى المحاولة لاحقاً.");
      setIsGenerating(false);
    }

    if (!customPrompt) {
      setQuestion(""); // clear input
    }
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(answer);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleSpeak = () => {
    if (!isSpeechAvailable || !answer) return;
    
    // Stop any existing speech
    window.speechSynthesis.cancel();
    
    const plainText = answer
      .replace(/[^\u0600-\u06FF\s\d\w.,?!]/g, "") // remove emojis/bullet points for smoother speech
      .substring(0, 400); // limit to avoid local crash

    const utterance = new SpeechSynthesisUtterance(plainText);
    utterance.lang = "ar-EG"; // Arabic Egypt layout matching Ibn Ramadan voice styling
    
    const persona = EXPERT_PERSONAS.find(p => p.id === activePersona);
    if (persona) {
      utterance.rate = persona.voiceRate;
    }
    
    utterance.onend = () => setIsSpeaking(false);
    utterance.onerror = () => setIsSpeaking(false);
    
    setIsSpeaking(true);
    window.speechSynthesis.speak(utterance);
  };

  const handleStopSpeaking = () => {
    if (isSpeechAvailable) {
      window.speechSynthesis.cancel();
    }
    setIsSpeaking(false);
  };

  const handleClearHistory = () => {
    if (window.confirm("هل أنت متأكد من رغبتك في إفراغ سجل الأسئلة بالكامل؟")) {
      setHistory([]);
      localStorage.removeItem("ramadan_live_history");
    }
  };

  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      presentationRef.current?.requestFullscreen().then(() => {
        setIsFullscreen(true);
      }).catch(err => {
        console.error(`Error attempting to enable full-screen mode: ${err.message}`);
      });
    } else {
      document.exitFullscreen();
      setIsFullscreen(false);
    }
  };

  // Listen to escape or exit fullscreen manually
  useEffect(() => {
    const handleFullscreenChange = () => {
      setIsFullscreen(!!document.fullscreenElement);
    };
    document.addEventListener("fullscreenchange", handleFullscreenChange);
    return () => document.removeEventListener("fullscreenchange", handleFullscreenChange);
  }, []);

  // Determine classes for output panel based on theme
  const getOutputBgClass = () => {
    switch (backgroundMode) {
      case "green":
        return "bg-[#00FF00] text-black border-none select-text"; // Solid green screen
      case "transparent":
        return "bg-transparent text-white border-2 border-dashed border-[#38bdf8]/40 backdrop-blur-sm select-text";
      case "neon":
        return "bg-black text-[#38bdf8] border-2 border-[#ec4899] shadow-[0_0_25px_rgba(236,72,153,0.3)] font-mono select-text";
      case "slate":
      default:
        return "bg-[#0f172a] text-[#f8fafc] border border-[#334155]/60 select-text";
    }
  };

  const getFontSizeClass = () => {
    switch (fontSize) {
      case "sm": return "text-sm";
      case "md": return "text-base";
      case "lg": return "text-lg md:text-xl";
      case "xl": return "text-xl md:text-2xl leading-relaxed";
      case "2xl": return "text-2xl md:text-3xl leading-relaxed font-bold";
      case "3xl": return "text-3xl md:text-4xl leading-loose font-extrabold";
      default: return "text-lg";
    }
  };

  return (
    <div className="space-y-6" id="ai-live-container">
      
      {/* Upper Streaming Overview Banner */}
      <div className="bg-gradient-to-r from-[#1e293b] to-[#0f172a] border border-[#334155] rounded-3xl p-6 relative overflow-hidden text-right shadow-[0_4px_30px_rgba(58,189,248,0.02)]">
        <div className="absolute top-0 left-0 w-64 h-64 bg-[#38bdf8]/5 rounded-full blur-3xl pointer-events-none"></div>
        <div className="absolute bottom-0 right-0 w-32 h-32 bg-[#ec4899]/5 rounded-full blur-xl pointer-events-none"></div>
        
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 relative z-10">
          
          <div className="space-y-1.5 flex-1">
            <div className="flex items-center justify-end gap-2">
              <span className="flex h-3.5 w-3.5 relative">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-rose-500 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-3.5 w-3.5 bg-rose-500"></span>
              </span>
              <span className="text-[11px] font-black tracking-wider text-rose-400 uppercase bg-rose-500/10 px-2.5 py-0.5 rounded-full border border-rose-500/20">
                LIVE BROADCAST ACTIVE
              </span>
              <h1 className="text-xl font-extrabold text-white tracking-tight">استوديو البث الرقمي (AI Live Studio)</h1>
            </div>
            
            <p className="text-xs text-[#94a3b8] max-w-2xl leading-relaxed">
              قم بصياغة إجابات استثنائية فورية لجمهورك على البث المباشر. تم تصميم هذه اللوحة وتكبير خطوطها بعناية لدمجها مباشرة في برامج البث مثل <span className="text-[#38bdf8] font-bold">OBS Studio</span> أو تيك توك لايف ستوديو، مع ميزات الكروما الخضراء لسهولة التفريغ في دقة متناهية.
            </p>
          </div>

          <div className="flex items-center gap-2 justify-end self-end md:self-center">
            <button
              onClick={() => {
                const randPromp = TEMPLATE_PROMPTS[Math.floor(Math.random() * TEMPLATE_PROMPTS.length)];
                setQuestion(randPromp.question);
              }}
              className="px-4 py-2 bg-[#1e293b] hover:bg-[#334155] text-xs font-bold text-white rounded-xl border border-[#334155] transition-all duration-300 flex items-center gap-1.5 cursor-pointer transform hover:scale-[1.02]"
            >
              <HelpCircle className="w-4 h-4 text-[#38bdf8]" />
              <span>اقتراح سؤال غني</span>
            </button>
          </div>
        </div>
      </div>

      {/* Main Studio Split Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">

        {/* Left Side: Dynamic Controls Console (5 cols) */}
        <div className="lg:col-span-5 space-y-6">
          
          {/* Question / Text Generative Box */}
          <div className="bg-[#1e293b] border border-[#334155] rounded-3xl p-5 text-right space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-[10.5px] font-black text-[#94a3b8] uppercase mr-1">صناعة وبث السؤال المقترح</span>
              <span className="p-1 px-2.5 bg-[#38bdf8]/10 text-[#38bdf8] text-[10px] font-bold rounded-lg border border-[#38bdf8]/20 flex items-center gap-1">
                <Sparkles className="w-3 h-3" />
                سريع ومنظم
              </span>
            </div>

            <form onSubmit={(e) => handleGenerate(e)} className="space-y-3">
              <div className="relative">
                <textarea
                  rows={4}
                  placeholder="اكتب هنا السؤال الموجه إليك من المتابعين أو تفاصيل النقاش الحالي..."
                  value={question}
                  onChange={(e) => setQuestion(e.target.value)}
                  className="w-full px-4 py-3 bg-[#0f172a] border border-[#334155] text-white rounded-xl text-xs font-semibold focus:outline-none focus:border-[#38bdf8] placeholder-[#94a3b8]/60 leading-relaxed text-right"
                />
              </div>

              {/* Persona Selectors */}
              <div className="space-y-2">
                <label className="block text-[11px] font-extrabold text-[#94a3b8] mr-1">شخصية الذكاء الاصطناعي النشطة للبث:</label>
                <div className="grid grid-cols-2 gap-2">
                  {EXPERT_PERSONAS.map((pers) => (
                    <button
                      key={pers.id}
                      type="button"
                      onClick={() => setActivePersona(pers.id)}
                      className={`p-2.5 rounded-xl border text-right transition-all duration-300 cursor-pointer ${
                        activePersona === pers.id
                          ? "bg-[#38bdf8]/10 border-[#38bdf8] text-white"
                          : "bg-[#0f172a]/80 border-[#334155] text-[#94a3b8] hover:border-slate-500 hover:text-white"
                      }`}
                    >
                      <div className="flex items-center justify-between mb-0.5">
                        <span className={`w-1.5 h-1.5 rounded-full ${activePersona === pers.id ? 'bg-[#38bdf8] animate-ping' : 'bg-slate-500'}`}></span>
                        <span className="text-[11px] font-black">{pers.name}</span>
                      </div>
                      <p className="text-[9px] text-[#94a3b8] leading-tight line-clamp-1">{pers.role}</p>
                    </button>
                  ))}
                </div>
              </div>

              <div className="flex gap-2.5">
                <button
                  type="submit"
                  disabled={isGenerating || !question.trim()}
                  className="flex-1 py-3 bg-[#38bdf8] hover:bg-[#38bdf8]/90 disabled:bg-[#334155] disabled:text-[#94a3b8] text-[#0f172a] font-extrabold text-xs rounded-xl shadow-[0_0_15px_rgba(56,189,248,0.2)] transition-all duration-300 flex items-center justify-center gap-2 cursor-pointer transform active:scale-95"
                >
                  {isGenerating ? (
                    <>
                      <RefreshCw className="w-4 h-4 animate-spin" />
                      <span>جاري صياغة الاستجابة الحية...</span>
                    </>
                  ) : (
                    <>
                      <Send className="w-4 h-4" />
                      <span>توليد وبث للإشارة الفورية</span>
                    </>
                  )}
                </button>
              </div>
            </form>

            {/* Quick Templates List */}
            <div className="space-y-2 pt-2 border-t border-[#334155]/60">
              <p className="text-[10px] font-bold text-[#94a3b8] mr-1">رؤوس موضوعات حية سريعة كليك واحد:</p>
              <div className="flex flex-wrap gap-1.5 justify-start direction-rtl">
                {TEMPLATE_PROMPTS.map((tp, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => {
                      setQuestion(tp.question);
                      handleGenerate(undefined, tp.question);
                    }}
                    className="px-2.5 py-1.5 bg-[#0f172a] hover:bg-[#38bdf8]/10 text-[#94a3b8] hover:text-white rounded-lg text-[10px] border border-[#334155] transition-all duration-300 cursor-pointer text-right"
                  >
                    {tp.title}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Livestream Options Card */}
          <div className="bg-[#1e293b] border border-[#334155] rounded-3xl p-5 text-right space-y-4">
            <span className="text-[10.5px] font-black text-[#94a3b8] block mr-1 uppercase">إعدادات تخصيص بث OBS وتيك توك</span>
            
            <div className="space-y-3 text-xs">
              
              {/* Back Color Overlay Switcher */}
              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] text-slate-400">اختر لون الترويق التلقائي في OBS</span>
                  <label className="font-extrabold text-[#94a3b8] flex items-center gap-1.5">
                    <Palette className="w-3.5 h-3.5 text-[#38bdf8]" />
                    <span>خلفية شاشة العرض</span>
                  </label>
                </div>
                <div className="grid grid-cols-4 gap-1.5 font-bold text-[10px]">
                  <button
                    onClick={() => setBackgroundMode("slate")}
                    className={`py-1.5 rounded-lg border text-center transition-all ${
                      backgroundMode === "slate" 
                        ? "bg-[#38bdf8] text-[#0f172a] border-[#38bdf8]" 
                        : "bg-[#0f172a] border-[#334155] text-[#94a3b8]"
                    }`}
                  >
                    كحلي معتم
                  </button>
                  <button
                    onClick={() => setBackgroundMode("green")}
                    className={`py-1.5 rounded-lg border text-center transition-all ${
                      backgroundMode === "green" 
                        ? "bg-[#00B140] text-white border-green-500 shadow-[0_0_10px_rgba(0,255,0,0.2)]" 
                        : "bg-[#0f172a] border-[#334155] text-[#94a3b8]"
                    }`}
                  >
                    كروما خضراء
                  </button>
                  <button
                    onClick={() => setBackgroundMode("transparent")}
                    className={`py-1.5 rounded-lg border text-center transition-all ${
                      backgroundMode === "transparent" 
                        ? "bg-slate-700 text-white border-slate-500" 
                        : "bg-[#0f172a] border-[#334155] text-[#94a3b8]"
                    }`}
                  >
                    شفافية حية
                  </button>
                  <button
                    onClick={() => setBackgroundMode("neon")}
                    className={`py-1.5 rounded-lg border text-center transition-all ${
                      backgroundMode === "neon" 
                        ? "bg-[#ec4899] text-white border-[#ec4899] shadow-[0_0_10px_rgba(236,72,153,0.3)]" 
                        : "bg-[#0f172a] border-[#334155] text-[#94a3b8]"
                    }`}
                  >
                    نيون صاخب
                  </button>
                </div>
              </div>

              {/* Font Size Adjuster */}
              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] text-slate-400">تحكم بمدى وضوح الأحرف لشاشات الموبايل</span>
                  <label className="font-extrabold text-[#94a3b8] flex items-center gap-1.5">
                    <Type className="w-3.5 h-3.5 text-[#38bdf8]" />
                    <span>حجم خط القراءة المباشرة</span>
                  </label>
                </div>
                <div className="grid grid-cols-6 gap-1 font-bold text-[10px]">
                  {(["sm", "md", "lg", "xl", "2xl", "3xl"] as const).map((sz) => (
                    <button
                      key={sz}
                      onClick={() => setFontSize(sz)}
                      className={`py-1 rounded-md border text-center uppercase transition-all ${
                        fontSize === sz 
                          ? "bg-[#38bdf8] text-[#0f172a] border-[#38bdf8]" 
                          : "bg-[#0f172a] border-[#334155] text-[#94a3b8]"
                      }`}
                    >
                      {sz}
                    </button>
                  ))}
                </div>
              </div>

              {/* Ticker marquee config */}
              <div className="space-y-2 pt-2 border-t border-[#334155]/60">
                <div className="flex items-center justify-between">
                  <button
                    type="button"
                    onClick={() => setIsEditingTicker(!isEditingTicker)}
                    className="text-[10px] text-[#38bdf8] hover:underline"
                  >
                    {isEditingTicker ? "حفظ وتثبيت" : "تعديل الشريط السفلي"}
                  </button>
                  <span className="font-bold text-[#94a3b8]">شريط الإعلانات الدوار أسفل البث</span>
                </div>
                {isEditingTicker ? (
                  <input
                    type="text"
                    value={streamTicker}
                    onChange={(e) => setStreamTicker(e.target.value)}
                    className="w-full px-3 py-1.5 bg-[#0f172a] border border-[#334155] text-white rounded-lg text-xs"
                  />
                ) : (
                  <p className="text-[10px] text-slate-400 bg-[#0f172a] p-2 rounded-lg border border-[#334155] truncate text-left font-mono">
                    {streamTicker}
                  </p>
                )}
              </div>

            </div>
          </div>

          {/* History Panel */}
          <div className="bg-[#1e293b] border border-[#334155] rounded-3xl p-5 text-right space-y-3">
            <div className="flex items-center justify-between">
              {history.length > 0 && (
                <button
                  onClick={handleClearHistory}
                  className="text-[10px] text-rose-400 hover:text-rose-300 flex items-center gap-1"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>إفراغ</span>
                </button>
              )}
              <h3 className="text-xs font-extrabold text-white flex items-center gap-1.5">
                <History className="w-4 h-4 text-[#38bdf8]" />
                <span>أحدث الاستفسارات المستولدة</span>
              </h3>
            </div>

            {history.length === 0 ? (
              <p className="text-[10.5px] text-[#94a3b8] py-4 text-center">لا توجد أسئلة سابقة في السجل حالياً.</p>
            ) : (
              <div className="space-y-2 max-h-48 overflow-y-auto pr-1">
                {history.map((item) => (
                  <button
                    key={item.id}
                    onClick={() => {
                      setAnswer(item.answer);
                      setActivePersona(item.persona);
                    }}
                    className="w-full p-2.5 rounded-xl bg-[#0f172a] hover:bg-[#38bdf8]/5 border border-[#334155] text-right transition-all flex flex-col gap-1 text-[11px] cursor-pointer"
                  >
                    <div className="flex justify-between items-center w-full">
                      <span className="text-[9px] text-[#38bdf8] bg-[#38bdf8]/10 px-1.5 py-0.2 rounded border border-[#38bdf8]/20 font-bold">
                        {EXPERT_PERSONAS.find(p => p.id === item.persona)?.name.split(" ")[1]}
                      </span>
                      <span className="text-[9px] text-slate-500 font-mono">{item.timestamp}</span>
                    </div>
                    <p className="text-white font-bold line-clamp-1 leading-relaxed">{item.question}</p>
                  </button>
                ))}
              </div>
            )}
          </div>

        </div>

        {/* Right Side: Magnificent Presentational Output Canvas (7 cols) */}
        <div className="lg:col-span-7 space-y-6">
          
          {/* Output Display Frame Box */}
          <div 
            ref={presentationRef}
            className={`rounded-3xl border transition-all duration-500 flex flex-col ${getOutputBgClass()} ${
              isFullscreen ? "p-10 h-screen w-screen fixed inset-0 z-50 overflow-hidden flex flex-col justify-between" : "p-6 relative min-h-[500px]"
            }`}
          >
            
            {/* Display header inside presentation frame */}
            <div className="flex items-center justify-between border-b pb-4 mb-4 border-[#334155]/60">
              
              {/* Quick tool controls */}
              {!isFullscreen && (
                <div className="flex items-center gap-2">
                  <button
                    onClick={handleCopy}
                    className="p-2 rounded-xl bg-[#1e293b]/85 hover:bg-[#334155] border border-[#334155] text-white transition-all transform active:scale-95 flex items-center justify-center cursor-pointer shadow-md"
                    title="نسخ الإجابة لمشاركتها"
                  >
                    {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4 text-[#38bdf8]" />}
                  </button>

                  {isSpeechAvailable && (
                    isSpeaking ? (
                      <button
                        onClick={handleStopSpeaking}
                        className="p-2 rounded-xl bg-rose-950/20 hover:bg-rose-900/30 border border-rose-900/40 text-rose-400 transition-all flex items-center justify-center cursor-pointer"
                        title="إيقاف قراءة الصوت"
                      >
                        <Square className="w-4 h-4" />
                      </button>
                    ) : (
                      <button
                        onClick={handleSpeak}
                        className="p-2 rounded-xl bg-emerald-950/20 hover:bg-emerald-900/30 border border-emerald-900/40 text-emerald-400 transition-all flex items-center justify-center cursor-pointer"
                        title="قراءة الإجابة صوتياً للمشاهدين"
                      >
                        <Volume2 className="w-4 h-4" />
                      </button>
                    )
                  )}

                  <button
                    onClick={toggleFullscreen}
                    className="p-2 rounded-xl bg-[#1e293b]/85 hover:bg-[#334155] border border-[#334155] text-white transition-all flex items-center justify-center cursor-pointer"
                    title="تفعيل العرض بملء الشاشة لـ OBS"
                  >
                    <Maximize2 className="w-4 h-4 text-[#38bdf8]" />
                  </button>
                </div>
              )}

              {isFullscreen && (
                <div className="flex items-center gap-2">
                  <button
                    onClick={toggleFullscreen}
                    className="p-2.5 rounded-xl bg-black/60 hover:bg-black/80 border border-[#334155] text-white transition-all"
                  >
                    <Minimize2 className="w-5 h-5 text-rose-400" />
                  </button>
                </div>
              )}

              {/* Branding/Status overlay inside frame */}
              <div className="text-right flex items-center gap-3">
                <div className="hidden sm:block">
                  <h3 className="text-xs font-black tracking-widest text-white uppercase font-mono">IBN RAMADAN AI LIVE</h3>
                  <p className="text-[9px] text-[#38bdf8] font-bold mt-0.5">صوتك وصورتك الذكية للأعمال</p>
                </div>
                <div className="w-9 h-9 rounded-xl bg-[#38bdf8]/10 border border-[#38bdf8]/20 flex items-center justify-center animate-pulse">
                  <Monitor className="w-5 h-5 text-[#38bdf8]" />
                </div>
              </div>

            </div>

            {/* Answer Display Board panel */}
            <div className={`flex-1 overflow-y-auto pr-1 scrollbar-thin text-right ${getFontSizeClass()}`}>
              {isGenerating && !answer ? (
                <div className="flex flex-col items-center justify-center h-48 space-y-4">
                  <div className="w-12 h-12 rounded-full border-4 border-[#334155] border-t-[#38bdf8] animate-spin"></div>
                  <p className="text-xs text-[#38bdf8] font-bold animate-pulse">الذكاء الاصطناعي يستدعي الحكمة حالاً...</p>
                </div>
              ) : (
                <div className="whitespace-pre-wrap leading-relaxed font-sans font-medium text-right pb-10">
                  {answer}
                </div>
              )}
              <div ref={outputEndRef} />
            </div>

            {/* Bottom Stream Bar Marquee */}
            <div className="mt-4 pt-3 border-t border-[#334155]/40 flex items-center overflow-hidden h-7">
              <div className="bg-[#38bdf8] text-[#0f172a] text-[10px] uppercase font-black px-2 py-0.5 rounded mr-3 shrink-0 tracking-widest select-none shadow">
                NEWS FLASH
              </div>
              <div className="overflow-hidden relative w-full h-full flex items-center">
                <div className="animate-marquee whitespace-nowrap text-xs text-[#38bdf8] absolute font-bold flex gap-4">
                  <span>{streamTicker}</span>
                  <span className="text-white">★</span>
                  <span>{streamTicker}</span>
                  <span className="text-white">★</span>
                  <span>{streamTicker}</span>
                </div>
              </div>
            </div>

          </div>

          {/* Camera overlay Mock visualization guide (Exclusive helpful Streamer UI) */}
          {showStreamOverlay && (
            <div className="p-4 bg-[#1e293b] border border-[#334155] rounded-[20px] text-right space-y-3">
              <div className="flex items-center justify-between">
                <button
                  onClick={() => setShowStreamOverlay(false)}
                  className="text-[10px] text-[#94a3b8] hover:text-white"
                >
                  إخفاء المخطط التوضيحي
                </button>
                <span className="text-xs font-extrabold text-white flex items-center gap-1">
                  <Video className="w-4 h-4 text-[#38bdf8]" />
                  <span>دليل دمج OBS Studio و كاميرا البث</span>
                </span>
              </div>
              <p className="text-[11px] text-[#94a3b8] leading-relaxed">
                لكي يظهر هذا الإخراج بجمالية خلفيتك الـ Live داخل <span className="text-white font-bold">OBS</span> أو <span className="text-white font-bold">TikTok Studio</span>:
              </p>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-[10.5px]">
                <div className="p-2.5 bg-[#0f172a] rounded-xl border border-[#334155]">
                  <p className="font-bold text-white mb-1 shrink-0">1. الطريقة الشفافة (الأسهل):</p>
                  <p className="text-slate-400">اختر خلفية <span className="text-[#38bdf8] font-bold">"شفافة"</span> من الخيارات، ثم أضف نافذة المتصفح كـ Source داخل OBS مع تفعيل الشفافية.</p>
                </div>
                <div className="p-2.5 bg-[#0f172a] rounded-xl border border-[#334155]">
                  <p className="font-bold text-white mb-1 shrink-0">2. استخدام الكروما الخضراء:</p>
                  <p className="text-slate-400">اختر خلفية <span className="text-emerald-400 font-bold">"كروما خضراء"</span>، ثم أضف فلتر <span className="text-[#38bdf8] font-bold">Chroma Key / كروما بصرية</span> في OBS لتفريغ اللون الأخضر فورياً.</p>
                </div>
              </div>
            </div>
          )}

        </div>

      </div>

    </div>
  );
}

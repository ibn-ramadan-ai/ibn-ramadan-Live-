import React, { useState } from "react";
import { ClientAccount, UserRole } from "../types";
import { Sparkles, Key, Building2, ShieldCheck, AlertCircle, ArrowLeft, User } from "lucide-react";

interface LoginGateProps {
  clients: ClientAccount[];
  onLogin: (role: UserRole, clientId?: string) => void;
}

const ADMIN_SECRET = "SR2026";

export default function LoginGate({ clients, onLogin }: LoginGateProps) {
  const [isAdmin, setIsAdmin] = useState(false);
  const [username, setUsername] = useState<string>("");
  const [password, setPassword] = useState<string>("");
  const [adminPin, setAdminPin] = useState<string>("");
  const [error, setError] = useState<string>("");

  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError("");

    if (isAdmin) {
      if (!adminPin) {
        setError("الرجاء إدخال رمز المرور السري للمسؤول");
        return;
      }
      // Admin check with constant value
      if (adminPin === ADMIN_SECRET) {
        onLogin("ADMIN");
      } else {
        setError("رمز المرور الخاص بالمسؤول غير صحيح! يرجى المحاولة الكود الصحيح للمنظومة");
      }
    } else {
      if (!username) {
        setError("الرجاء إدخال اسم المستخدم بشكل صحيح");
        return;
      }
      if (!password) {
        setError("الرجاء إدخال كلمة المرور الخاصة بحسابك");
        return;
      }

      // Find client using username case-insensitively
      const client = clients.find(c => c.username.toLowerCase() === username.trim().toLowerCase());
      if (!client) {
        setError("اسم المستخدم غير مسجل بنظام ابن رمضان Business OS");
        return;
      }

      if (client.status === "SUSPENDED") {
        setError("هذا الترخيص موقوف حالياً. يرجى مراجعة إدارة ابن رمضان Business OS");
        return;
      }

      if (client.password === password) {
        onLogin("CLIENT", client.id);
      } else {
        setError("كلمة المرور التي أدخلتها غير صحيحة! يرجى المحاولة مرة أخرى");
      }
    }
  };

  return (
    <div className="max-w-md mx-auto my-12" id="login-gate-container">
      {/* Brand Logo & Header */}
      <div className="text-center mb-8">
        <div className="inline-flex p-4 rounded-3xl bg-[#1e293b] border border-[#334155] shadow-[0_0_20px_rgba(56,189,248,0.15)] mb-4 animate-pulse">
          <Sparkles className="w-10 h-10 text-[#38bdf8]" />
        </div>
        <h1 className="text-3xl font-extrabold text-white tracking-tight">Ibn Ramadan Business OS</h1>
        <p className="text-[#38bdf8] text-sm font-bold mt-1">Business Intelligence & Automation Platform</p>
        <p className="text-[#94a3b8] text-xs mt-2 leading-relaxed">
          نظام محاذاة وتوليد الخطط الرقمية المخصص للشركات والمصانع
        </p>
      </div>

      {/* Main Login Card */}
      <div className="bg-[#1e293b] border border-[#334155] rounded-[20px] p-6 shadow-[0_4px_30px_rgba(56,189,248,0.05)] text-right">
        {/* Toggle Mode */}
        <div className="flex gap-2 p-1.5 bg-[#0f172a] rounded-xl mb-6 border border-[#334155]">
          <button
            type="button"
            onClick={() => {
              setIsAdmin(false);
              setError("");
              setUsername("");
              setPassword("");
            }}
            className={`flex-1 py-2 text-center text-xs font-bold rounded-lg transition-all duration-300 ${
              !isAdmin
                ? "bg-[#38bdf8] text-[#0f172a] font-extrabold shadow-[0_0_12px_rgba(56,189,248,0.3)] scale-[1.02]"
                : "text-[#94a3b8] hover:text-white"
            }`}
          >
            تسجيل دخول العملاء
          </button>
          <button
            type="button"
            onClick={() => {
              setIsAdmin(true);
              setError("");
              setAdminPin("");
            }}
            className={`flex-1 py-2 text-center text-xs font-bold rounded-lg transition-all duration-300 ${
              isAdmin
                ? "bg-[#38bdf8] text-[#0f172a] font-extrabold shadow-[0_0_12px_rgba(56,189,248,0.3)] scale-[1.02]"
                : "text-[#94a3b8] hover:text-white"
            }`}
          >
            لوحة المسؤول (Admin)
          </button>
        </div>

        <form onSubmit={handleLoginSubmit} className="space-y-5">
          {!isAdmin ? (
            <>
              {/* Client Username */}
              <div>
                <label className="block text-xs font-bold text-[#94a3b8] mb-2 mr-1">
                  اسم المستخدم (Username)
                </label>
                <div className="relative">
                  <User className="absolute top-3.5 right-3 w-4 h-4 text-[#94a3b8]" />
                  <input
                    type="text"
                    placeholder="مثال: helal_palace"
                    value={username}
                    onChange={(e) => {
                      setUsername(e.target.value);
                      setError("");
                    }}
                    className="w-full pl-3 pr-9 py-3 bg-[#0f172a] border border-[#334155] text-white rounded-xl text-xs font-bold focus:outline-none focus:border-[#38bdf8] focus:ring-1 focus:ring-[#38bdf8]"
                  />
                </div>
              </div>

              {/* Client Password */}
              <div>
                <label className="block text-xs font-bold text-[#94a3b8] mb-2 mr-1">
                  كلمة المرور (Password)
                </label>
                <div className="relative">
                  <Key className="absolute top-3.5 right-3 w-4 h-4 text-[#94a3b8]" />
                  <input
                    type="password"
                    placeholder="••••••••"
                    value={password}
                    onChange={(e) => {
                      setPassword(e.target.value);
                      setError("");
                    }}
                    className="w-full pl-3 pr-9 py-3 bg-[#0f172a] border border-[#334155] text-white rounded-xl text-xs font-bold focus:outline-none focus:border-[#38bdf8] focus:ring-1 focus:ring-[#38bdf8]"
                  />
                </div>
              </div>
            </>
          ) : (
            <>
              <div className="p-3 bg-sky-950/20 border border-[#334155] rounded-xl text-xs text-[#38bdf8] leading-relaxed mb-4">
                <span className="font-bold block mb-1">لوحة الإدارة الفنية</span>
                مخصصة لسعد رمضان وممثلي الإدارة لتهيئة التراخيص والخطط.
              </div>

              {/* Admin PIN */}
              <div>
                <label className="block text-xs font-bold text-[#94a3b8] mb-2 mr-1">
                  كود الدخول السري للمسؤول
                </label>
                <div className="relative">
                  <Key className="absolute top-3.5 right-3 w-4 h-4 text-[#94a3b8]" />
                  <input
                    type="password"
                    placeholder="أدخل كود المسؤول الفني"
                    value={adminPin}
                    onChange={(e) => {
                      setAdminPin(e.target.value);
                      setError("");
                    }}
                    className="w-full pl-3 pr-9 py-3 bg-[#0f172a] border border-[#334155] text-white rounded-xl text-xs font-bold focus:outline-none focus:border-[#38bdf8] focus:ring-1 focus:ring-[#38bdf8]"
                  />
                </div>
              </div>
            </>
          )}

          {error && (
            <div className="flex items-start gap-2 p-3 bg-rose-500/10 border border-rose-500/20 rounded-xl text-xs text-rose-300">
              <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
              <span>{error}</span>
            </div>
          )}

          <button
            type="submit"
            className="w-full py-3 bg-[#38bdf8] text-[#0f172a] hover:bg-sky-400 font-extrabold text-xs rounded-xl shadow-[0_4px_12px_rgba(56,189,248,0.2)] hover:shadow-[0_0_20px_rgba(56,189,248,0.4)] transition-all duration-300 transform hover:scale-[1.05] cursor-pointer"
          >
            {isAdmin ? "دخول المسؤول الفني" : "تفعيل الجليسة الذكية"}
          </button>
        </form>
      </div>
    </div>
  );
}

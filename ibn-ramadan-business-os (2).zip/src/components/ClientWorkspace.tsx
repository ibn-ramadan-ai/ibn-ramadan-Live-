import React, { useState } from "react";
import { ClientAccount } from "../types";
import { 
  Sparkles, FileText, ArrowUpRight, BarChart3, HelpCircle, Download, 
  Play, RefreshCw, Send, MessageSquare, CheckCircle2, Star, 
  Coins, TrendingUp, AlertTriangle, Lightbulb, Award
} from "lucide-react";

interface ClientWorkspaceProps {
  client: ClientAccount;
  onLogout: () => void;
}

export default function ClientWorkspace({ client, onLogout }: ClientWorkspaceProps) {
  const [activeTab, setActiveTab] = useState<"scripts" | "marketing" | "finance" | "cs" | "bi_portal">(() => {
    if (client.features.scripts) return "scripts";
    if (client.features.marketing) return "marketing";
    if (client.features.finance) return "finance";
    if (client.features.cs) return "cs";
    return "bi_portal";
  });

  // Generator internal states
  const [isGenerating, setIsGenerating] = useState(false);
  const [promptInput, setPromptInput] = useState("");
  const [generatedResult, setGeneratedResult] = useState<string>("");

  // Scripts templates based on client category
  const runScriptsGenerator = () => {
    setIsGenerating(true);
    setGeneratedResult("");
    setTimeout(() => {
      setIsGenerating(false);
      let output = "";
      if (client.category.includes("أثاث") || client.category.includes("دمياط")) {
        output = `🔮 [ابن رمضان Business OS] - مسودة النص الإعلاني المولد لـ (${client.brandName}):

الهدف: الترويج لغرف النوم الفاخرة والصالونات المصنوعة يدوياً بقوة خشب الزان الأحمر الروماني.

🎬 مشهد 1: لقطة سينمائية مقربة تظهر تفاصيل الحفر اليدوي (الأويما) وسهم الضوء ينعكس على القشرة الطبيعية.
صوت المعلق (بالعامية المصرية الأصيلة): "في دمياط بنقول الفن مبيتكررش.. بس في قصر غرفتنا، الفخامة تورث من جيل لجيل."

🎙️ مشهد 2: المذيع جالس على الكنبة الرئيسية للصالون المريح جداً، في صالة العرض الخاصة بكم.
المعلق: "مش أي خشب يبقى أثاث، ومش أي يد فنان تطوع الزان ليبقى تحفة معمرة. مع ${client.brandName}، الفن اتجسد في بيتك."

📌 الإجراء والهدف التسويقي (CTA): "زورونا الآن في صالة العرض الكبرى للاستفادة من خصم الافتتاح الحصري لعملاء الإنترنت، أو تواصلوا فوراً على رسائل الصفحة لمقاسات مخصصة مع شحن مجاني لكافة المحافظات."

💡 الكلمات المفتاحية المؤثرة: #أثاث_دمياطي #زان_أحمر #قصر_الهلال #أثاث_الوتيدي #فن_الأويما`;
      } else if (client.category.includes("عقارات") || client.category.includes("استثمار")) {
        output = `🔮 [ابن رمضان Business OS] - نص تسويق عقاري للمبيعات التنافسية لـ (${client.brandName}):

الهدف: استهداف المغتربين والمستثمرين لفلل وقصور الكيان الراقي مع تسهيلات غير مسبوقة.

🎙️ الكوبي الإعلاني (نص منشور فيسبوك الطويل):
"عايز أمان حقيقي لأولادك وكمان استثمار بيزيد كل دقيقة؟ 💎
في قلب القاهرة الجديدة، بنوفرلك مش مجرد جدران.. بنوفر جودة حياة، مساحات خضراء شاسعة، وتصميم معامري ملكي يليق باسم عيلتكم الكريمة.

ليه تختار ${client.companyName}؟
✅ أقل مقدم حجز في التجمع الخامس (فقط 5%).
✅ فترات سداد مريحة تمتد لـ 8 سنوات بدون فوائد.
✅ استلام فوري أو نصف تشطيب بمواصفات عالية.

📞 للأسرع في الحجز، اضغط على زر 'إرسال رسالة' لمعاينة الفيلا غداً بالتنسيق مع المستشار العقاري المباشر."`;
      } else {
        output = `🔮 [ابن رمضان Business OS] - إستراتيجية سكربت لمنصة (${client.brandName}):

السياق المستهدف: ${client.category}

📌 محتوى الإعلان (سيناريو بوعي استهلاكي):
المذيع: "تعبت من مشاكل الشحن والخدمات التقليدية البطيئة؟ ابن رمضان Business OS حط ايده على المشكلة وعالجها مع ${client.brandName}!

الفوائد الثلاثة الكبرى في هذا الإصدار:
1. جودة معززة ومضمونة 100% بموجب تراخيص رسمية وعقود موثقة.
2. خدمة عملاء مهذبة ترد على استفساراتكم خلال ثوان معدودة.
3. التزام دقيق بمواعيد التسليم والشحن المحلي.

للاستفادة، اترك تعليقاً بكلمة (تفعيل) واقبل مراجعة العرض الاستثنائي فوراً في صندوق الوارد."`;
      }
      setGeneratedResult(output);
    }, 1200);
  };

  // Marketing strategy simulator
  const runMarketingPlan = () => {
    setIsGenerating(true);
    setGeneratedResult("");
    setTimeout(() => {
      setIsGenerating(false);
      const output = `📋 [خطة التسويق الذكية من ابن رمضان Business OS] لـ (${client.brandName}):

المرحلة 1: اختراق السوق المحلي (الأيام 1-15)
- التركيز على إعلانات الفيديو القصيرة (TikTok & Instagram Reels) بمحتوى عفوي يظهر "خلف الكواليس" والتصنيع.
- الميزانية الموصى بها: 15 دولار يومياً لمحافظات (القاهرة، الجيزة، الدقهلية، دمياط، الإسكندرية).

المرحلة 2: تعظيم قيمة المصداقية (الأيام 16-30)
- تجميع مراجعات حقيقية وتصوير العملاء بعد استلام المنتجات أو تملك العقارات.
- إطلاق حملة الاستهداف الذهبى للجمهور المهتم بالصفحات الكبرى المنافسة.

المرحلة 3: خطة الكوبونات والمناسبات الخاصة
- إطلاق عرض "كوبون ابن رمضان" بنسبة خصم 8% حصرياً لرفع نسبة المبيعات وتصفية المخزون الحالي.`;
      setGeneratedResult(output);
    }, 1100);
  };

  // Financial calculations
  const [priceItem, setPriceItem] = useState("12000");
  const [costItem, setCostItem] = useState("8000");
  const runFinanceAudit = () => {
    setIsGenerating(true);
    setGeneratedResult("");
    setTimeout(() => {
      setIsGenerating(false);
      const p = parseFloat(priceItem) || 0;
      const c = parseFloat(costItem) || 0;
      if (p <= 0 || c <= 0) {
        setGeneratedResult("الرجاء إدخال أرقام صحيحة أكبر من الصفر للحساب المالي الفعال.");
        return;
      }
      const profit = p - c;
      const profitMargin = ((profit / p) * 100).toFixed(1);
      const estimatedTax = (profit * 0.155).toFixed(1); // 15.5% trade tax estimate
      
      const output = `💸 [الاستشاري المالي الذكي لـ ${client.brandName}]:

📊 الأداء المالي لكل وحدة مباعة:
- إجمالي قيمة البيع: ${p.toLocaleString()} ج.م
- كلفة التصنيع والتشغيل الشاملة: ${c.toLocaleString()} ج.م
- الربح الصافي التقريبي لكل قطعة: ${profit.toLocaleString()} ج.م
- هامش الربح الإجمالي: ${profitMargin}% [مستوى الربح مميز ومستقر]

📑 التقدير الاسترشادي للضرائب والمصروفات الإضافية بمصر:
- ضريبة القيمة المضافة المحتملة واستقطاع المنبع: ${estimatedTax} ج.م تقريباً.
- لتوليد أرباح صافية تبلغ 150,000 ج.م شهرياً، يُنصح ببيع مقاس شهري لا يقل عن ${(150000 / profit).toFixed(0)} وحدة من هذا الصنف.`;
      setGeneratedResult(output);
    }, 1000);
  };

  // Customer Service replies simulation
  const [csInput, setCsInput] = useState("بكام الغرفة دي وفين عنوان معرضكم بالتفصيل؟");
  const runCsSimulation = () => {
    setIsGenerating(true);
    setGeneratedResult("");
    setTimeout(() => {
      setIsGenerating(false);
      let output = "";
      if (csInput.includes("بكام") || csInput.includes("سعر") || csInput.includes("السعر")) {
        output = `💬 [مساعد خدمة العملاء المحايد من ابن رمضان Business OS] للرد الفوري الموصى به:

"أهلاً بك يا فندم في ${client.brandName} نورتنا جداً! 🌸
السعر بيختلف حسب المقاسات والتعديلات المناسبة لذوقك الرفيع، لكن بنطمنك إن رينج الأسعار منافس جداً وبنبدأ من عروض حصرية ممتازة.

سيبنا نبعتلك التفاصيل الكاملة وصور حية من المعرض على الخاص حالاً ومعه الكتالوج الجديد. ممكن بعد إذنك رقم الموبايل أو رغبتك في شحن مجاني؟"`;
      } else {
        output = `💬 [مساعد خدمة العملاء المحايد من ابن رمضان Business OS] للرد التفاعلي:

"مساء الخير يا فندم! سعداء جداً بتواصلك مع مؤسسة ${client.companyName}.
استفسارك محل اهتمامنا الفوري، وفريق الدعم الفني والمبيعات هيتواصل مع حضرتك خلال دقايق معدودة لتوضيح التفاصيل ومساعدتك في اختيار الأفضل.

إذا حابب نسجل طلبك فوراً للسرعة، سيب اسمك ورقم تليفونك وهيتم الاتصال بك تليفونياً."`;
      }
      setGeneratedResult(output);
    }, 800);
  };

  return (
    <div className="space-y-6 text-right" id="client-workspace-container">
      
      {/* 1. Welcoming Hero */}
      <div className="bg-[#1e293b] border border-[#334155] rounded-[20px] p-6 shadow-[0_4px_20px_rgba(56,189,248,0.03)] flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <h2 className="text-xl font-extrabold text-white">مرحباً بك في بوابة {client.brandName}</h2>
            <Star className="w-5 h-5 text-[#38bdf8] fill-[#38bdf8]/20" />
          </div>
          <p className="text-xs text-[#94a3b8]">
            الشركة المالكة: <span className="text-[#38bdf8] font-bold">{client.companyName}</span> | الترخيص مفعل وحالته <span className="text-[#38bdf8] font-bold">نشطة</span>
          </p>
        </div>

        <div className="flex items-center gap-2 bg-[#0f172a] p-2 rounded-xl border border-[#334155]">
          <span className="text-[10px] text-[#94a3b8] font-bold">باقة الترخيص:</span>
          <span className="text-xs font-black text-[#38bdf8]">
            {client.subscription === "ELITE" ? "ELITE النخبة الفاخرة" : client.subscription === "GOLD" ? "GOLD الذهبية" : "BASIC الأساسية"}
          </span>
        </div>
      </div>

      {/* 2. Workspace Navigation */}
      <div className="bg-[#1e293b] border border-[#334155] rounded-[20px] p-2.5 flex flex-wrap gap-1.5 shadow-[0_4px_12px_rgba(58,189,248,0.02)]">
        
        {client.features.scripts ? (
          <button
            onClick={() => { setActiveTab("scripts"); setGeneratedResult(""); }}
            className={`px-4 py-2 text-xs font-extrabold rounded-xl transition duration-300 cursor-pointer ${
              activeTab === "scripts"
                ? "bg-[#38bdf8] text-[#0f172a] shadow-[0_0_12px_rgba(58,189,248,0.25)]"
                : "text-[#94a3b8] hover:text-white"
            }`}
          >
            توليد السكربتات وصناع المحتوى
          </button>
        ) : (
          <span className="px-4 py-2 text-xs text-slate-600 cursor-not-allowed line-through">توليد السكربتات (مغلق)</span>
        )}

        {client.features.marketing ? (
          <button
            onClick={() => { setActiveTab("marketing"); setGeneratedResult(""); }}
            className={`px-4 py-2 text-xs font-extrabold rounded-xl transition duration-300 cursor-pointer ${
              activeTab === "marketing"
                ? "bg-[#38bdf8] text-[#0f172a] shadow-[0_0_12px_rgba(58,189,248,0.25)]"
                : "text-[#94a3b8] hover:text-white"
            }`}
          >
            إستراتيجيات التسويق والانتشار
          </button>
        ) : (
          <span className="px-4 py-2 text-xs text-slate-600 cursor-not-allowed line-through">إستراتيجيات التسويق (مغلق)</span>
        )}

        {client.features.finance ? (
          <button
            onClick={() => { setActiveTab("finance"); setGeneratedResult(""); }}
            className={`px-4 py-2 text-xs font-extrabold rounded-xl transition duration-300 cursor-pointer ${
              activeTab === "finance"
                ? "bg-[#38bdf8] text-[#0f172a] shadow-[0_0_12px_rgba(58,189,248,0.25)]"
                : "text-[#94a3b8] hover:text-white"
            }`}
          >
            الاستشاري المالي والتسعير
          </button>
        ) : (
          <span className="px-4 py-2 text-xs text-slate-600 cursor-not-allowed line-through">الاستشاري المالي (ترقية المطلوبة)</span>
        )}

        {client.features.cs ? (
          <button
            onClick={() => { setActiveTab("cs"); setGeneratedResult(""); }}
            className={`px-4 py-2 text-xs font-extrabold rounded-xl transition duration-300 cursor-pointer ${
              activeTab === "cs"
                ? "bg-[#38bdf8] text-[#0f172a] shadow-[0_0_12px_rgba(58,189,248,0.25)]"
                : "text-[#94a3b8] hover:text-white"
            }`}
          >
            بوت خدمة العملاء ومكافحة التردد
          </button>
        ) : (
          <span className="px-4 py-2 text-xs text-slate-600 cursor-not-allowed line-through">دعم المبيعات (مغلق)</span>
        )}

        {client.features.bi_portal ? (
          <button
            onClick={() => { setActiveTab("bi_portal"); setGeneratedResult(""); }}
            className={`px-4 py-2 text-xs font-extrabold rounded-xl transition duration-300 cursor-pointer ${
              activeTab === "bi_portal"
                ? "bg-[#38bdf8] text-[#0f172a] shadow-[0_0_12px_rgba(58,189,248,0.25)]"
                : "text-[#94a3b8] hover:text-white"
            }`}
          >
            بوابة الإحصاء والـ BI
          </button>
        ) : (
          <span className="px-4 py-2 text-xs text-slate-600 cursor-not-allowed line-through">تقارير BI الفخمة (ترقية المطلوبة)</span>
        )}

      </div>

      {/* 3. Render Active Generator Panel */}
      <div className="bg-[#1e293b] border border-[#334155] rounded-[20px] p-6 shadow-[0_4px_25px_rgba(56,189,248,0.02)] space-y-6">
        
        {/* Tab 1: AI Scripts */}
        {activeTab === "scripts" && (
          <div className="space-y-4">
            <div className="flex items-center gap-2 text-[#38bdf8]">
              <Sparkles className="w-5 h-5" />
              <h3 className="font-extrabold text-sm text-white">مولد السكربتات الذكي للأبعاد المرئية</h3>
            </div>
            <p className="text-xs text-[#94a3b8] leading-relaxed">
              يقوم مساعد ابن رمضان Business OS بدراسة طبيعة نشاطك بقطاع <span className="text-[#38bdf8] font-bold">({client.category})</span> وصناعة فكرة وسيناريو إعلاني فوري لجذب أنظار العملاء بالتصنيع المحلي.
            </p>

            <div className="bg-[#0f172a] p-4 rounded-xl border border-[#334155] space-y-3">
              <label className="block text-xs font-bold text-[#94a3b8]">أضف فكرة ترغب بالتركيز عليها بالنص (اختياري)</label>
              <input
                type="text"
                placeholder="مثال: خصم خاص 20% على غرف الأطفال بمناسبة نهاية العام ونشحن لكل مصر"
                value={promptInput}
                onChange={(e) => setPromptInput(e.target.value)}
                className="w-full px-3 py-2.5 bg-[#1e293b] border border-[#334155] text-white rounded-xl text-xs font-bold focus:outline-none focus:border-[#38bdf8]"
              />
              <button
                onClick={runScriptsGenerator}
                disabled={isGenerating}
                className="px-5 py-2.5 bg-[#38bdf8] text-[#0f172a] hover:bg-sky-400 font-extrabold text-xs rounded-xl shadow-[0_4px_12px_rgba(58,189,248,0.2)] disabled:opacity-50 transition transform hover:scale-[1.05] cursor-pointer"
              >
                {isGenerating ? "جاري الاستماع للنبض والتوليد..." : "توليد النص الإعلاني الذكي"}
              </button>
            </div>
          </div>
        )}

        {/* Tab 2: Marketing Strategy */}
        {activeTab === "marketing" && (
          <div className="space-y-4">
            <div className="flex items-center gap-2 text-[#38bdf8]">
              <Award className="w-5 h-5 animate-spin" />
              <h3 className="font-extrabold text-sm text-white">إستراتيجية التسويق الفطن للأعمال المصرية</h3>
            </div>
            <p className="text-xs text-[#94a3b8] leading-relaxed">
              تصفية موازنات الإعلانات ومرحلة الوصول إلى العميل المناسب المهتم بجودة المنتج وعظمة الـ Trade.
            </p>

            <div className="bg-[#0f172a] p-4 rounded-xl border border-[#33415510] space-y-3 text-right">
              <p className="text-xs text-white">
                اضغط لتوليد وتحيين خطة تسويق موسمية لبراند <span className="text-[#38bdf8] font-bold">({client.brandName})</span> تضمن كسر الملل التسويقي.
              </p>
              <button
                onClick={runMarketingPlan}
                disabled={isGenerating}
                className="px-5 py-2.5 bg-[#38bdf8] text-[#0f172a] hover:bg-sky-400 font-extrabold text-xs rounded-xl shadow-[0_4px_12px_rgba(58,189,248,0.2)] disabled:opacity-50 transition transform hover:scale-[1.05] cursor-pointer"
              >
                {isGenerating ? "جاري صياغة الخطة والجدول..." : "توليد الخطة التسويقية الذكية"}
              </button>
            </div>
          </div>
        )}

        {/* Tab 3: Finance Auditor */}
        {activeTab === "finance" && (
          <div className="space-y-4">
            <div className="flex items-center gap-2 text-[#38bdf8]">
              <Coins className="w-5 h-5" />
              <h3 className="font-extrabold text-sm text-white">أداة تسعير المنتجات وحساب نسبة الربح الصافي</h3>
            </div>
            <p className="text-xs text-[#94a3b8]">
              ادخل قيمة تصنيع القطعة وقيمة بيعها النهائي للجمهور لحساب الجدوى الإدارية الفعالة.
            </p>

            <div className="bg-[#0f172a] p-4 rounded-xl border border-[#334155] space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-[#94a3b8] mb-1">سعر بيع المنتج للجمهور (ج.م)</label>
                  <input
                    type="number"
                    value={priceItem}
                    onChange={(e) => setPriceItem(e.target.value)}
                    className="w-full px-3 py-2 bg-[#1e293b] border border-[#334155] text-white rounded-xl text-xs font-mono text-center"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-[#94a3b8] mb-1">كلفة الإنتاج والشحن والعمولات (ج.م)</label>
                  <input
                    type="number"
                    value={costItem}
                    onChange={(e) => setCostItem(e.target.value)}
                    className="w-full px-3 py-2 bg-[#1e293b] border border-[#334155] text-white rounded-xl text-xs font-mono text-center"
                  />
                </div>
              </div>
              <button
                onClick={runFinanceAudit}
                className="px-5 py-2.5 bg-[#38bdf8] text-[#0f172a] hover:bg-sky-400 font-extrabold text-xs rounded-xl shadow-[0_4px_12px_rgba(58,189,248,0.2)] transition transform hover:scale-[1.05] cursor-pointer"
              >
                تحليل التدفق والهامش المالي
              </button>
            </div>
          </div>
        )}

        {/* Tab 4: Customer service bot */}
        {activeTab === "cs" && (
          <div className="space-y-4">
            <div className="flex items-center gap-2 text-[#38bdf8]">
              <FileText className="w-5 h-5" />
              <h3 className="font-extrabold text-sm text-white">مساعد إجابات العملاء والرد التفاعلي المقنع</h3>
            </div>
            <p className="text-xs text-[#94a3b8]">
              اكتب الرسالة أو السؤال الذي يطرحه زبائن الصفحة، وسيتكفل مساعد ابن رمضان Business OS بصياغة ألطف رد تفاعلي يدفع العميل لاتخاذ قرار الشراء فوراً.
            </p>

            <div className="bg-[#0f172a] p-4 rounded-xl border border-[#334155] space-y-3">
              <label className="block text-xs font-bold text-[#94a3b8]">استفسار العميل الشائع:</label>
              <textarea
                value={csInput}
                onChange={(e) => setCsInput(e.target.value)}
                className="w-full px-3 py-2.5 bg-[#1e293b] border border-[#334155] text-white rounded-xl text-xs font-bold h-16 focus:outline-none focus:border-[#38bdf8]"
                placeholder="اكتب مثل: غالية جداً الصالونات دي ليه؟ أو ابعتولى العنوان.."
              />
              <button
                onClick={runCsSimulation}
                className="px-5 py-2.5 bg-[#38bdf8] text-[#0f172a] hover:bg-sky-400 font-extrabold text-xs rounded-xl shadow-[0_4px_12px_rgba(58,189,248,0.2)] transition transform hover:scale-[1.05] cursor-pointer"
              >
                توليد رد ذكي ممتص للتردد
              </button>
            </div>
          </div>
        )}

        {/* Tab 5: BI Portal charts */}
        {activeTab === "bi_portal" && (
          <div className="space-y-5">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-[#38bdf8]">
                <BarChart3 className="w-5 h-5" />
                <h3 className="font-extrabold text-sm text-white">منصة البيانات الحية لبراند ({client.brandName})</h3>
              </div>
              <span className="text-[10px] text-emerald-400 animate-pulse bg-emerald-500/10 px-2.5 py-0.5 rounded-full font-bold">
                ● تحديث حي مباشر
              </span>
            </div>

            <p className="text-xs text-[#94a3b8]">
              بوابة إحصائية متكاملة لبيان مرات التفاعل، زيارات موقعك، وحجم المبيعات المحققة بموجب خطط ابن رمضان Business OS.
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="p-4 bg-[#0f172a] border border-[#334155] rounded-xl text-right">
                <span className="text-[10px] text-[#94a3b8] font-bold block">معدل التفاعل الإعلاني</span>
                <span className="text-xl font-black text-white block mt-1">+24.8%</span>
                <div className="w-full bg-[#1e293b] h-1.5 rounded-full mt-2 overflow-hidden">
                  <div className="bg-[#38bdf8] h-full" style={{ width: "75%" }}></div>
                </div>
              </div>
              
              <div className="p-4 bg-[#0f172a] border border-[#334155] rounded-xl text-right">
                <span className="text-[10px] text-[#94a3b8] font-bold block">سلات الشراء النشطة اليوم</span>
                <span className="text-xl font-black text-white block mt-1">42 طلب</span>
                <div className="w-full bg-[#1e293b] h-1.5 rounded-full mt-2 overflow-hidden">
                  <div className="bg-[#38bdf8] h-full" style={{ width: "45%" }}></div>
                </div>
              </div>

              <div className="p-4 bg-[#0f172a] border border-[#334155] rounded-xl text-right">
                <span className="text-[10px] text-[#94a3b8] font-bold block">مجموع المبيعات المعلقة</span>
                <span className="text-xl font-black text-[#38bdf8] block mt-1">118,400 ج.م</span>
                <div className="w-full bg-[#1e293b] h-1.5 rounded-full mt-2 overflow-hidden">
                  <div className="bg-[#38bdf8] h-full" style={{ width: "85%" }}></div>
                </div>
              </div>
            </div>

            <div className="p-4 bg-[#0f172a] border border-[#334155] rounded-xl text-center space-y-2">
              <p className="text-xs text-[#94a3b8]">مؤشر نبض المنصة العام واستقرار تدفق المبيعات قيد التتبع حالياً</p>
              <div className="flex justify-center items-center gap-1.5 text-[11px] text-[#38bdf8] font-bold">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                <span>جميع الأجهزة والخوادم تعمل بطاقة خضراء آمنة</span>
              </div>
            </div>
          </div>
        )}

        {/* 4. Display Simulated Output Results */}
        {generatedResult && (
          <div className="mt-6 border-t border-[#334155] pt-6 animate-fadeIn text-right">
            <div className="flex items-center justify-between mb-3 text-xs bg-[#0f172a] p-2.5 rounded-xl border border-[#334155]">
              <div className="flex items-center gap-1.5 text-emerald-400 font-bold">
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>تم توليد النتائج الفورية بنجاح</span>
              </div>
              <button
                onClick={() => {
                  navigator.clipboard.writeText(generatedResult);
                  alert("تم مواءمة ونسخ المخرجات للحافظة بنجاح!");
                }}
                className="text-white hover:text-[#38bdf8] transition-all flex items-center gap-1 font-bold text-[10.5px] cursor-pointer"
              >
                <span>نسخ للمسودة</span>
                <Download className="w-3 h-3" />
              </button>
            </div>

            <div className="bg-[#0f172a] border border-[#334155]/60 p-5 rounded-xl font-mono text-xs text-white leading-relaxed whitespace-pre-wrap select-all">
              {generatedResult}
            </div>

            <div className="mt-3 flex items-center gap-2 p-3 bg-sky-950/20 border border-[#334155] rounded-xl text-[11px] text-[#94a3b8]">
              <Lightbulb className="w-4 h-4 text-[#38bdf8] shrink-0" />
              <span>هذا الإخراج معدّل ومصقول بحكمة بواسطة ابن رمضان Business OS ليتلاءم فورياً مع ذوق المستهلك بقطاع ({client.category}).</span>
            </div>
          </div>
        )}

      </div>

    </div>
  );
}

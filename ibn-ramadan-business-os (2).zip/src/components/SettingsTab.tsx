import React, { useState } from "react";
import { Server, Settings, Cpu, Shield, RefreshCw, Key, Database, Globe2, HelpCircle } from "lucide-react";

export default function SettingsTab() {
  const [modelType, setModelType] = useState("gemini-1.5-flash-pro");
  const [serverRegion, setServerRegion] = useState("cairo-north-1");
  const [useCache, setUseCache] = useState(true);
  const [backupFreq, setBackupFreq] = useState("daily");
  
  const [isSyncing, setIsSyncing] = useState(false);
  const [syncStatus, setSyncStatus] = useState("النظام مستقر تماماً ومحدث");

  const triggerManualSync = () => {
    setIsSyncing(true);
    setSyncStatus("جاري فحص حالة الشبكة وحلقة الترخيص...");
    setTimeout(() => {
      setIsSyncing(false);
      setSyncStatus("اكتمل الفحص! تم التحقق من سلامة 3 رخص نشطة وتأمينها");
    }, 1200);
  };

  return (
    <div className="space-y-6 text-right" id="settings-tab-container">
      
      {/* Settings Intro Card */}
      <div className="bg-[#1e293b] border border-[#334155] rounded-[20px] p-6 shadow-[0_4px_12px_rgba(58,189,248,0.02)]">
        <div className="flex items-center gap-3 mb-2">
          <div className="w-10 h-10 rounded-xl bg-[#0f172a] border border-[#334155] flex items-center justify-center">
            <Settings className="w-5 h-5 text-[#38bdf8]" />
          </div>
          <div>
            <h2 className="text-sm font-extrabold text-white">إعدادات النظام والنبض السحابي</h2>
            <p className="text-[10px] text-[#94a3b8]">تخصيص أداء الماكينة السحابية لـ Ibn Ramadan Business OS</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        
        {/* Tech Configuration */}
        <div className="bg-[#1e293b] border border-[#334155] rounded-[20px] p-5 space-y-4">
          <div className="flex items-center gap-2 text-[#38bdf8] border-b border-[#334155] pb-2">
            <Cpu className="w-4 h-4" />
            <span className="text-xs font-black text-white">القلب المحرك وموديل الذكاء</span>
          </div>

          <div className="space-y-3">
            <div>
              <label className="block text-[11px] font-bold text-[#94a3b8] mb-1">النموذج الاسترشادي المفتاحى</label>
              <select
                value={modelType}
                onChange={(e) => setModelType(e.target.value)}
                className="w-full px-3 py-2 bg-[#0f172a] border border-[#334155] text-white rounded-xl text-xs font-bold focus:outline-none"
              >
                <option value="gemini-1.5-flash-pro">Ibn Ramadan Business OS Elite Engine v3</option>
                <option value="gemini-1.5-pro">DeepMind Gemini Advanced C-S (دقيق ومكلف)</option>
                <option value="gemini-2.0-flash">Gemini 2.0 Ultra Fast Response (سرعة استثنائية)</option>
              </select>
            </div>

            <div>
              <label className="block text-[11px] font-bold text-[#94a3b8] mb-1">خادم الانسياب والمنطقة</label>
              <select
                value={serverRegion}
                onChange={(e) => setServerRegion(e.target.value)}
                className="w-full px-3 py-2 bg-[#0f172a] border border-[#334155] text-white rounded-xl text-xs font-bold focus:outline-none"
              >
                <option value="cairo-north-1">بوابة القاهرة شمال (الأسرع داخل جمهورية مصر)</option>
                <option value="europe-west3">أوروبا الغربية - فرانكفورت (النسخ الاحتياطي السريع)</option>
                <option value="us-east-4">أمريكا الشرقية (بديل عند الضغط المروري)</option>
              </select>
            </div>

            <div className="flex items-center justify-between p-2.5 bg-[#0f172a] rounded-xl border border-[#334155] mt-2">
              <span className="text-xs text-white">تفعيل كاش الإجابات (توفير الحصة السحابية)</span>
              <input
                type="checkbox"
                checked={useCache}
                onChange={() => setUseCache(!useCache)}
                className="w-4 h-4 rounded text-[#38bdf8] bg-slate-900 border-[#334155] focus:ring-[#38bdf8]"
              />
            </div>
          </div>
        </div>

        {/* Database & Security Operations checks */}
        <div className="bg-[#1e293b] border border-[#334155] rounded-[20px] p-5 space-y-4">
          <div className="flex items-center gap-2 text-[#38bdf8] border-b border-[#334155] pb-2">
            <Database className="w-4 h-4" />
            <span className="text-xs font-black text-white">قاعدة التراخيص الذاكرية والتأمين</span>
          </div>

          <p className="text-[11px] text-[#94a3b8] leading-relaxed">
            تتم استعادة وضبط تراخيص شركات الأثاث والعقارات والتجارة بموجب ملف سحابي مشفر ومحفوظ مسبقاً لحساب مؤسسة سعد للتسويق الرقمي بجمهورية مصر العربية.
          </p>

          <div className="p-3 bg-[#0f172a] border border-[#334155] rounded-xl space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span className="text-[#94a3b8]">حالة الاتصال بالخادم:</span>
              <span className="text-[#38bdf8] font-bold">نشط ومستقر تماماً</span>
            </div>
            <div className="flex items-center justify-between text-xs">
              <span className="text-[#94a3b8]">الحاق بالذاكرة العشوائية:</span>
              <span className="text-[#94a3b8] font-mono">1.2 MB / Local Storage Active</span>
            </div>
          </div>

          <div className="pt-2">
            <button
              onClick={triggerManualSync}
              disabled={isSyncing}
              className="w-full py-2 bg-[#38bdf8] text-[#0f172a] hover:bg-sky-400 font-extrabold text-xs rounded-xl shadow-[0_2px_8px_rgba(58,189,248,0.2)] disabled:opacity-50 transition transform hover:scale-[1.03] flex items-center justify-center gap-1.5 cursor-pointer"
            >
              <RefreshCw className={`w-3.5 h-3.5 text-[#0f172a] ${isSyncing ? "animate-spin" : ""}`} />
              <span>{isSyncing ? "جاري تدقيق التراخيص والنبض..." : "فحص وتدقيق التراخيص والشبكة"}</span>
            </button>
            <p className="text-[10px] text-[#94a3b8] text-center mt-2.5 font-bold leading-relaxed">{syncStatus}</p>
          </div>
        </div>

      </div>

      {/* Guide FAQs and Credit */}
      <div className="bg-[#1e293b] border border-[#334155] border-dashed rounded-[20px] p-5 text-right space-y-3">
        <h3 className="text-xs font-extrabold text-white flex items-center gap-2">
          <Globe2 className="w-4 h-4 text-[#38bdf8]" />
          <span>الشروط التشغيلية العامة لمنظومة ابن رمضان AI Live</span>
        </h3>
        <ul className="space-y-1 text-[11px] text-[#94a3b8]">
          <li className="list-disc list-inside mr-1">
            لا يجب مشاركة بيانات المرور واسم المستخدم الخاص بكل حساب ترخيص مع الأطراف الخارجية غير المعنية بإدارة المبيعات أو كتابة السكربت الإعلاني.
          </li>
          <li className="list-disc list-inside mr-1">
            يُحظر تجميد التراخيص وإيقاف براندات العملاء إلا بموافقة مسبقة من سعد رمضان أو إدارة مؤسسة سعد.
          </li>
          <li className="list-disc list-inside mr-1">
            يمكن لكل براند توليد حتى 5,000 إستراتيجية شهرياً بموجب الترخيص الحالي.
          </li>
        </ul>
      </div>

    </div>
  );
}
